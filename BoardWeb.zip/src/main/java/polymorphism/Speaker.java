package polymorphism;

public interface Speaker {
	
	void volumeUp();
	void volumeDown();
	

}
